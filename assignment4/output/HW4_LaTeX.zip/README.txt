Compile HW4_report.tex with Tectonic or pdfLaTeX (two passes). Figures are included.
